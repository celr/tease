function runInitialAnimations() {
  $(".recttool5").toggleClass("recttool5-animation");
}
